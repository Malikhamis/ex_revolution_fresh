/**
 * API Configuration for Admin Dashboard
 * Handles dynamic API URLs for both local and mobile access
 */

class ApiConfig {
    constructor() {
        this.baseUrl = this.getBaseUrl();
    }

    getBaseUrl() {
        const currentHost = window.location.hostname;
        const currentProtocol = window.location.protocol;
        const currentPort = window.location.port;

        // Always use the same server for API calls (direct endpoints)
        // This works because we have direct API endpoints in start-website.js
        return `${currentProtocol}//${currentHost}${currentPort ? ':' + currentPort : ''}/api`;
    }

    // Authentication endpoints
    get auth() {
        return `${this.baseUrl}/auth`;
    }

    // Newsletter endpoints
    get newsletter() {
        return {
            subscribers: `${this.baseUrl}/newsletter/subscribers`,
            templates: `${this.baseUrl}/newsletter/templates`,
            send: `${this.baseUrl}/newsletter/send`
        };
    }

    // Contact endpoints
    get contacts() {
        return `${this.baseUrl}/contacts`;
    }

    // Quote endpoints
    get quotes() {
        return `${this.baseUrl}/quotes`;
    }

    // User endpoints
    get users() {
        return `${this.baseUrl}/users`;
    }

    // Settings endpoints
    get settings() {
        return `${this.baseUrl}/settings`;
    }

    // Case Studies endpoints
    get caseStudies() {
        return `${this.baseUrl}/case-studies`;
    }

    // Blog Posts endpoints
    get blogPosts() {
        return `${this.baseUrl}/blog-posts`;
    }

    // Health check endpoint
    get health() {
        return `${this.baseUrl}/health`;
    }

    // Utility method to make authenticated requests
    async makeRequest(url, options = {}) {
        const token = localStorage.getItem('token');

        const defaultOptions = {
            headers: {
                'Content-Type': 'application/json',
                ...(token && { 'x-auth-token': token })
            }
        };

        const mergedOptions = {
            ...defaultOptions,
            ...options,
            headers: {
                ...defaultOptions.headers,
                ...options.headers
            }
        };

        try {
            console.log(`Making request to: ${url}`);
            const response = await fetch(url, mergedOptions);

            // Handle authentication errors
            if (response.status === 401) {
                localStorage.removeItem('token');
                window.location.href = 'login.html';
                return null;
            }

            return response;
        } catch (error) {
            console.error('API request failed:', error);
            throw error;
        }
    }

    // Utility method for GET requests
    async get(url) {
        return this.makeRequest(url, { method: 'GET' });
    }

    // Utility method for POST requests
    async post(url, data) {
        return this.makeRequest(url, {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }

    // Utility method for PUT requests
    async put(url, data) {
        return this.makeRequest(url, {
            method: 'PUT',
            body: JSON.stringify(data)
        });
    }

    // Utility method for DELETE requests
    async delete(url) {
        return this.makeRequest(url, { method: 'DELETE' });
    }

    // Debug method to log current configuration
    logConfig() {
        console.log('API Configuration:', {
            currentHost: window.location.hostname,
            baseUrl: this.baseUrl,
            endpoints: {
                auth: this.auth,
                newsletter: this.newsletter,
                contacts: this.contacts,
                quotes: this.quotes,
                users: this.users,
                settings: this.settings,
                caseStudies: this.caseStudies,
                blogPosts: this.blogPosts,
                health: this.health
            }
        });
    }
}

// Create global instance
window.apiConfig = new ApiConfig();

// Log configuration for debugging
console.log('API Config initialized for host:', window.location.hostname);
window.apiConfig.logConfig();
