/**
 * Content Manager - Dynamic Content Loading System
 * Connects main website with admin panel changes
 */

class ContentManager {
    constructor() {
        this.apiBase = window.location.origin;
        this.cache = new Map();
        this.cacheTimeout = 5 * 60 * 1000; // 5 minutes
    }

    /**
     * Get case studies from API or cache
     */
    async getCaseStudies() {
        const cacheKey = 'case-studies';
        const cached = this.cache.get(cacheKey);

        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            return cached.data;
        }

        try {
            const response = await fetch(`${this.apiBase}/api/public/case-studies`);
            if (response.ok) {
                const data = await response.json();
                this.cache.set(cacheKey, {
                    data: data,
                    timestamp: Date.now()
                });
                return data;
            }
        } catch (error) {
            console.warn('Failed to load case studies from API, using fallback');
        }

        // Fallback to static data if API fails
        return this.getFallbackCaseStudies();
    }

    /**
     * Get blog posts from API or cache
     */
    async getBlogPosts() {
        const cacheKey = 'blog-posts';
        const cached = this.cache.get(cacheKey);

        if (cached && Date.now() - cached.timestamp < this.cacheTimeout) {
            return cached.data;
        }

        try {
            const response = await fetch(`${this.apiBase}/api/public/blog-posts`);
            if (response.ok) {
                const data = await response.json();
                this.cache.set(cacheKey, {
                    data: data,
                    timestamp: Date.now()
                });
                return data;
            }
        } catch (error) {
            console.warn('Failed to load blog posts from API, using fallback');
        }

        // Fallback to static data if API fails
        return this.getFallbackBlogPosts();
    }

    /**
     * Get a specific case study by slug
     */
    async getCaseStudy(slug) {
        const caseStudies = await this.getCaseStudies();
        return caseStudies.find(cs => cs.slug === slug);
    }

    /**
     * Get a specific blog post by slug
     */
    async getBlogPost(slug) {
        const blogPosts = await this.getBlogPosts();
        return blogPosts.find(bp => bp.slug === slug);
    }

    /**
     * Render case studies grid
     */
    async renderCaseStudiesGrid(containerId, options = {}) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const caseStudies = await this.getCaseStudies();
        const filteredStudies = options.featured ?
            caseStudies.filter(cs => cs.featured && cs.status === 'published') :
            caseStudies.filter(cs => cs.status === 'published');

        const limit = options.limit || filteredStudies.length;
        const studiesToShow = filteredStudies.slice(0, limit);

        container.innerHTML = studiesToShow.map(caseStudy => `
            <div class="case-study-card" data-category="${caseStudy.industry.toLowerCase().replace(/\s+/g, '-')}">
                <img src="${caseStudy.image}" alt="${caseStudy.title}" class="case-study-image" loading="lazy">
                <div class="case-study-content">
                    <p class="case-study-category">${caseStudy.industry}</p>
                    <h3 class="case-study-title">${caseStudy.title}</h3>
                    <p class="case-study-description">${caseStudy.excerpt}</p>
                    <div class="case-study-results">
                        <h4>Technologies:</h4>
                        <ul>
                            ${caseStudy.technologies.map(tech => `<li>${tech}</li>`).join('')}
                        </ul>
                    </div>
                    <a href="case-studies/${caseStudy.slug}.html" class="case-study-link" style="color: #ffffff !important;">View Case Study</a>
                </div>
            </div>
        `).join('');
    }

    /**
     * Render blog posts grid
     */
    async renderBlogPostsGrid(containerId, options = {}) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const blogPosts = await this.getBlogPosts();
        const filteredPosts = options.featured ?
            blogPosts.filter(bp => bp.featured && bp.status === 'published') :
            blogPosts.filter(bp => bp.status === 'published');

        const limit = options.limit || filteredPosts.length;
        const postsToShow = filteredPosts.slice(0, limit);

        container.innerHTML = postsToShow.map(post => `
            <article class="blog-card">
                <div class="blog-image">
                    <img src="${post.image}" alt="${post.title}" loading="lazy">
                    <div class="blog-category">${post.category}</div>
                </div>
                <div class="blog-content">
                    <div class="blog-meta">
                        <span class="blog-author">
                            <i class="fas fa-user"></i> ${post.author}
                        </span>
                        <span class="blog-date">
                            <i class="fas fa-calendar"></i> ${this.formatDate(post.publishedAt)}
                        </span>
                    </div>
                    <h3 class="blog-title">
                        <a href="blog/${post.slug}.html">${post.title}</a>
                    </h3>
                    <p class="blog-excerpt">${post.excerpt}</p>
                    <div class="blog-tags">
                        ${post.tags.map(tag => `<span class="blog-tag">${tag}</span>`).join('')}
                    </div>
                    <a href="blog/${post.slug}.html" class="blog-link">Read More <i class="fas fa-arrow-right"></i></a>
                </div>
            </article>
        `).join('');
    }

    /**
     * Render case study detail page
     */
    async renderCaseStudyDetail(slug, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const caseStudy = await this.getCaseStudy(slug);
        if (!caseStudy) {
            container.innerHTML = '<p>Case study not found.</p>';
            return;
        }

        // Update page title and meta
        document.title = `${caseStudy.title} - Case Study | Ex Revolution Technology`;

        // Update meta description
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
            metaDesc.setAttribute('content', caseStudy.excerpt);
        }

        // Render content (this would be expanded based on your case study template)
        container.innerHTML = `
            <div class="case-study-detail">
                <h1>${caseStudy.title}</h1>
                <div class="case-study-meta">
                    <span>Client: ${caseStudy.client}</span>
                    <span>Industry: ${caseStudy.industry}</span>
                    <span>Published: ${this.formatDate(caseStudy.publishedAt)}</span>
                </div>
                <img src="${caseStudy.image}" alt="${caseStudy.title}" class="case-study-hero-image">
                <div class="case-study-content">
                    ${caseStudy.content}
                </div>
                <div class="case-study-technologies">
                    <h3>Technologies Used:</h3>
                    <div class="tech-tags">
                        ${caseStudy.technologies.map(tech => `<span class="tech-tag">${tech}</span>`).join('')}
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Render blog post detail page
     */
    async renderBlogPostDetail(slug, containerId) {
        const container = document.getElementById(containerId);
        if (!container) return;

        const blogPost = await this.getBlogPost(slug);
        if (!blogPost) {
            container.innerHTML = '<p>Blog post not found.</p>';
            return;
        }

        // Update page title and meta
        document.title = `${blogPost.title} | Ex Revolution Technology Blog`;

        // Update meta description
        const metaDesc = document.querySelector('meta[name="description"]');
        if (metaDesc) {
            metaDesc.setAttribute('content', blogPost.excerpt);
        }

        // Render content (this would be expanded based on your blog template)
        container.innerHTML = `
            <article class="blog-post-detail">
                <header class="blog-post-header">
                    <div class="blog-post-meta">
                        <span class="category">${blogPost.category}</span>
                        <span class="date">${this.formatDate(blogPost.publishedAt)}</span>
                        <span class="author">By ${blogPost.author}</span>
                    </div>
                    <h1>${blogPost.title}</h1>
                    <p class="blog-post-excerpt">${blogPost.excerpt}</p>
                </header>
                <img src="${blogPost.image}" alt="${blogPost.title}" class="blog-post-hero-image">
                <div class="blog-post-content">
                    ${blogPost.content}
                </div>
                <footer class="blog-post-footer">
                    <div class="blog-post-tags">
                        ${blogPost.tags.map(tag => `<span class="tag">${tag}</span>`).join('')}
                    </div>
                </footer>
            </article>
        `;
    }

    /**
     * Format date for display
     */
    formatDate(dateString) {
        if (!dateString) return 'Not published';
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }

    /**
     * Clear cache to force refresh
     */
    clearCache() {
        this.cache.clear();
    }

    /**
     * Refresh content on the page
     */
    async refreshContent() {
        this.clearCache();

        // Re-render case studies if container exists
        const caseStudiesContainer = document.getElementById('case-studies-container');
        if (caseStudiesContainer) {
            await this.renderCaseStudiesGrid('case-studies-container');
        }

        // Re-render blog posts if container exists
        const blogPostsContainer = document.getElementById('blog-posts-container');
        if (blogPostsContainer) {
            await this.renderBlogPostsGrid('blog-posts-container');
        }

        console.log('✅ Content refreshed successfully');
    }

    /**
     * Set up auto-refresh for content changes
     */
    setupAutoRefresh(intervalMinutes = 5) {
        setInterval(() => {
            this.refreshContent();
        }, intervalMinutes * 60 * 1000);
    }

    /**
     * Fallback case studies data
     */
    getFallbackCaseStudies() {
        return [
            {
                id: 1,
                title: "Custom Website for Usangu Logistics",
                slug: "usangu-logistics",
                excerpt: "We designed and developed a modern, responsive website for Usangu Logistics that showcases their transportation and logistics services.",
                content: "<p>Usangu Logistics needed a professional web presence to showcase their transportation and logistics services.</p>",
                image: "/assets/images/digital_marketing_concept.webp",
                client: "Usangu Logistics",
                industry: "Transportation & Logistics",
                technologies: ["HTML5", "CSS3", "JavaScript", "Responsive Design"],
                status: "published",
                featured: true,
                publishedAt: "2024-01-15",
                createdAt: "2024-01-10"
            }
            // Add other fallback case studies...
        ];
    }

    /**
     * Fallback blog posts data
     */
    getFallbackBlogPosts() {
        return [
            {
                id: 1,
                title: "The Future of Predictive Analytics in Inventory Management",
                slug: "predictive-analytics-inventory",
                excerpt: "Discover how predictive analytics is revolutionizing inventory management and helping businesses optimize their supply chains.",
                content: "<p>Predictive analytics is transforming how businesses manage their inventory.</p>",
                image: "/assets/images/predictive-analytics.jpg",
                author: "Ex Revolution Team",
                category: "Technology",
                tags: ["Analytics", "Inventory", "AI", "Supply Chain"],
                status: "published",
                featured: true,
                publishedAt: "2024-01-25",
                createdAt: "2024-01-20"
            }
            // Add other fallback blog posts...
        ];
    }
}

// Create global instance
window.contentManager = new ContentManager();
