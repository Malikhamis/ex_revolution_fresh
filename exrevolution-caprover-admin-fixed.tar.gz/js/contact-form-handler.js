/**
 * Contact Form Handler
 * Handles contact form submissions using the API service
 */

document.addEventListener('DOMContentLoaded', function() {
    initContactForm();
});

/**
 * Initialize contact form
 */
function initContactForm() {
    const contactForm = document.getElementById('contactForm');

    if (!contactForm) {
        // Contact form not found - this is normal for pages without contact forms
        return;
    }

    contactForm.addEventListener('submit', async function(e) {
        e.preventDefault();

        // Show loading state
        const submitButton = this.querySelector('button[type="submit"]');
        const originalButtonText = submitButton.textContent;
        submitButton.textContent = 'Sending...';
        submitButton.disabled = true;

        // Get form data as an object
        const formDataObj = {
            name: document.getElementById('name').value,
            email: document.getElementById('email').value,
            phone: document.getElementById('phone').value,
            subject: document.getElementById('service').value || 'Contact Form Inquiry',
            message: document.getElementById('message').value
        };

        console.log('Submitting form with data:', formDataObj);
        console.log('API URL:', window.ExRevolutionAPI ? 'API service loaded' : 'API service not loaded');

        try {
            // Submit form using direct fetch to API
            const apiUrl = `${window.location.protocol}//${window.location.host}/api/contact`;
            console.log('Submitting to API URL:', apiUrl);

            const apiResponse = await fetch(apiUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(formDataObj)
            });

            const response = await apiResponse.json();
            console.log('API response:', response);

            if (response.success) {
                // Show success message
                document.getElementById('formSuccess').style.display = 'block';
                document.getElementById('formError').style.display = 'none';

                // Reset form
                contactForm.reset();
            } else {
                // Show error message
                document.getElementById('formError').textContent = response.message || 'Something went wrong. Please try again.';
                document.getElementById('formError').style.display = 'block';
                document.getElementById('formSuccess').style.display = 'none';
            }
        } catch (error) {
            console.error('Error submitting contact form:', error);
            document.getElementById('formError').textContent = 'Network error. Please check your connection and try again.';
            document.getElementById('formError').style.display = 'block';
            document.getElementById('formSuccess').style.display = 'none';
        } finally {
            // Restore button state
            submitButton.textContent = originalButtonText;
            submitButton.disabled = false;
        }
    });
}

/**
 * Show form message
 * @param {HTMLElement} form - The form element
 * @param {string} type - Message type ('success' or 'error')
 * @param {string} message - Message text
 */
function showFormMessage(form, type, message) {
    // Remove any existing messages
    const existingMessage = form.querySelector('.form-message');
    if (existingMessage) {
        existingMessage.remove();
    }

    // Create message element
    const messageElement = document.createElement('div');
    messageElement.classList.add('form-message', `form-message-${type}`);
    messageElement.textContent = message;

    // Add message to form
    form.appendChild(messageElement);

    // Scroll to message
    messageElement.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    // Remove message after 5 seconds if it's a success message
    if (type === 'success') {
        setTimeout(() => {
            messageElement.remove();
        }, 5000);
    }
}
